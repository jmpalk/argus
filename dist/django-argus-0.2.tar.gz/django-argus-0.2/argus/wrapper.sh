#!/bin/bash

python3 ./run_masscan.py $1 $2 $3
