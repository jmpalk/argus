from django.apps import AppConfig


class ArgusConfig(AppConfig):
    name = 'argus'
